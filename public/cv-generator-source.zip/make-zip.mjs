import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const archiver = require('archiver');

const outputDir = path.resolve('public');
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

const outputPath = path.join(outputDir, 'cv-generator-source.zip');
const output = fs.createWriteStream(outputPath);
const archive = archiver('zip', { zlib: { level: 9 } });

output.on('close', () => {
  console.log(`Archive created successfully: ${archive.pointer()} total bytes`);
});

archive.on('error', (err) => {
  throw err;
});

archive.pipe(output);

// Append files and directories excluding node_modules, .git, dist, db files
archive.glob('**/*', {
  cwd: process.cwd(),
  ignore: [
    'node_modules/**',
    '.git/**',
    'dist/**',
    'public/cv-generator-source.zip',
    '*.db',
    '*.log',
    '.env',
  ],
  dot: true,
});

archive.finalize();
